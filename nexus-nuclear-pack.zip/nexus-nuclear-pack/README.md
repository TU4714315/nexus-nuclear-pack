# Nexus Nuclear Pack
هذا “باك” ملفات مواصفة/هيكل (Skeleton) جاهزة للحفظ.

## ما الموجود؟
- `NUCLEAR_SPEC.md` : المواصفة شبه النووية
- `wit/` : عقد الـ WASM plugins (WIT)
- `config/` : budget + policy
- `catalog/` : capability catalog (cost priors)
- `db/` : SQLite schema
- `bootstrap/` : سكربت واحد ينشئ workspace جاهز ويفتح VS Code
- `.vscode/` : إعدادات تشغيل تلقائي (Placeholder)

## طريقة التشغيل (حفظ + فتح)
راجع: `SAVE_GUIDE.md`
